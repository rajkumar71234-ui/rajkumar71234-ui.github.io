# Minimal Wealth Advisory Pvt Ltd — website

A static, six-page site. No build step, no framework, no dependencies. Open
`index.html` in a browser and it works.

```
index.html          Home
about.html          About Us  (philosophy, the elephant, process, FAQ)
products.html       Products  (MF, PMS, Bonds, AIF, SIF, Insurance)
team.html           Team      (Rajkumar S — founder bio)
testimonials.html   Testimonials
contact.html        Contact   (enquiry form)
favicon.svg
assets/css/style.css
assets/js/main.js
assets/img/logo.svg
```

---

## Design

| | |
|---|---|
| Accent (logo vermilion) | `#E0402B` |
| Ink / body text | `#1C1C1C` / `#3D3A36` |
| Background | `#FAF8F5` (off-white), `#F4F1EB` (alt sections) |
| Rules & borders | `#E4DFD6` |
| Typeface | Inter (Google Fonts), 400–700 |

The elephant runs as **photography**, generated to match the palette — muted,
warm, on off-white. One image per product (herd = mutual funds, lone elephant =
PMS, footprint = bonds, raised trunk = AIF, mother-and-calf = SIF, head and ear =
insurance), four on the About page, three team placeholders, the hero and the
booking band. All in `assets/img/`.

To swap any of them, drop a replacement in at the same filename and size:

| File | Used for | Size |
|---|---|---|
| `elephant-hero.jpg` | homepage hero | 1300 × 1400 |
| `elephant-cta.jpg` | booking band panel | 900 × 1300 |
| `p-*.jpg` | six product cards | 860 × 538 |
| `t-*.jpg` | four About traits | 280 × 280 |
| `team-*.jpg` | three team placeholders | 560 × 700 |
| `rajkumar.jpg` | founder photo | 720 × 900 |

---

## Before you publish — replace these

**1. The logo is done.** Traced from your file, pixel for pixel, and rebuilt as
vector so it stays sharp at any size. It lives inline in the header and footer of
all six pages, plus `assets/img/logo.svg` and `favicon.svg`. Nothing to do.

**2. Testimonials.** Every quote on `testimonials.html` is placeholder copy
written to show the layout. Replace them with real, written-permission client
quotes, and **delete the yellow notice block** near the top of that page.

**3. Contact details.** Search and replace across all six files:

- `hello@minimalwealth.in` → your real email
- `+91 00000 00000` and `wa.me/910000000000` → your real number
- `[Address line 1]` / `[Address line 2]` / `[PIN]` → your office address

**4. Registration details.** The footer of every page carries
`CIN: [to be added] · AMFI ARN: [to be added] · SEBI Reg: [to be added]`.
Fill these in. As a private limited company distributing or advising on these
products in India you will need the applicable registrations — AMFI ARN for
mutual fund distribution, SEBI RIA if you charge a fee for advice, IRDAI for
insurance — and they must be displayed. Worth a quick call with a compliance
consultant before the site goes live.

**5. Your fee model.** `about.html`, FAQ question 5 has a bracketed placeholder.
State plainly how you get paid.

**6. Team page.** Two of the three cards under "The rest of the herd" are
`[Name]` placeholders. Fill them in or delete the cards.

**7. Founder photo is in** — `assets/img/rajkumar.jpg`, colour-corrected to
remove the magenta cast from the original. Swap the file if you have a better one;
keep the same name and it just works.

---

## The booking band

Every page except Contact ends with a dark **"Get a free portfolio review —
30 minutes, virtually"** band, with a two-field form (name + phone). It behaves
like the contact form below: no backend, opens the visitor's mail client
pre-filled. Give the `<form id="booking-form">` an `action` to wire it to a real
service and the JavaScript stands down automatically.

## The chatbot

`assets/js/chat.js` — a scripted assistant, bottom-right on every page. No API,
no backend, no running cost, and it cannot say anything you did not write.

It answers six things: where to start, which product you need, what a SIF is,
whether you need ₹50 lakh, how you get paid, and booking a review. Every branch
routes back to the booking form.

**To edit it**, open `chat.js` and change the `NODES` object at the top. Each
node is `{ say: [...messages], opts: [[label, next-node, isPrimary]] }`. Adding a
question means adding one node and one option — no other file changes.

**One thing you must edit:** the `fees` node still has a bracketed placeholder,
same as the About FAQ.

## The contact form

There is **no backend**. By default, submitting the form opens the visitor's
mail client with everything pre-filled. That works, but it loses people on
phones.

To wire up a real form, pick a free service and add an `action` to the `<form>`
in `contact.html`:

```html
<form class="form" id="enquiry-form" method="POST"
      action="https://formspree.io/f/YOUR_ID">
```

The JavaScript automatically stands down as soon as an `action` is present.
[Formspree](https://formspree.io), [Web3Forms](https://web3forms.com) and
Netlify Forms all work without changing anything else.

---

## Hosting

It is a plain static site, so almost anything works.

**Netlify or Cloudflare Pages (easiest):** drag the whole folder onto
[app.netlify.com/drop](https://app.netlify.com/drop). Live in about ten seconds
on a temporary URL; point your domain at it from the site settings.

**GitHub Pages:** create a repo, push these files to the root of `main`, then
Settings → Pages → Source: `main` / `root`.

**Traditional hosting (Hostinger, GoDaddy, cPanel):** upload the contents of the
folder — not the folder itself — into `public_html`.

For a custom domain (`minimalwealth.in` or similar), add the domain in your
host's dashboard and update the nameservers or A record at your registrar.

---

## Editing

Everything is hand-written HTML. The header, footer and disclaimer are repeated
in each of the six files — if you change one, change all six. The quickest way
is find-and-replace across the folder in any editor (VS Code: `Ctrl+Shift+H`).

To change the accent colour site-wide, edit one line at the top of
`assets/css/style.css`:

```css
--accent: #E0402B;
```

The two `stroke="#E0402B"` values in the inline logo SVGs are the only
hard-coded colours; everything else inherits.
