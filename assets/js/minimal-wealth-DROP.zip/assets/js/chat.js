/* =========================================================================
   Minimal Wealth Advisory — scripted assistant
   No backend, no API, no cost. Answers set questions and routes to booking.
   To add or edit a question, add an entry to NODES below.
   ========================================================================= */
(function () {
  "use strict";

  var BOOK_URL = "contact.html";

  /* -------------------------------------------------------- the script -- */
  var NODES = {
    start: {
      say: [
        "Hello. I'm the Minimal Wealth assistant.",
        "I can answer the questions we get asked most — or book you a 30-minute portfolio review. What would help?"
      ],
      opts: [
        ["I don't know where to start", "start_here"],
        ["Which product do I need?", "which"],
        ["What is a SIF?", "sif"],
        ["Do I need ₹50 lakh?", "minimums"],
        ["How do you get paid?", "fees"],
        ["Book a review", "book", true]
      ]
    },

    start_here: {
      say: [
        "That's the most common place to be, and it's fine.",
        "We start by putting <strong>everything on one page</strong> — your funds, policies, loans, income and expenses. Most people have never seen it all in one view.",
        "In the first conversation the output is usually not a new investment. It's a <em>shorter</em> list, with two or three things you can stop doing straight away."
      ],
      opts: [
        ["What should I bring?", "bring"],
        ["Which product do I need?", "which"],
        ["Book a review", "book", true],
        ["Something else", "start"]
      ]
    },

    bring: {
      say: [
        "Nothing is mandatory for the first call. But the more of this you have, the more useful it is:",
        "• Latest mutual fund or demat statement<br>• Life and health insurance policies<br>• Outstanding loans and EMIs<br>• Rough monthly income and expenses<br>• Any goals already in your head"
      ],
      opts: [
        ["Book a review", "book", true],
        ["Back to the start", "start"]
      ]
    },

    which: {
      say: [
        "The goal decides the product — never the other way around.",
        "Almost always in this order: <strong>1.</strong> Term life and health cover, if anyone depends on your income. <strong>2.</strong> Six months of expenses somewhere liquid. <strong>3.</strong> Mutual funds mapped to each written goal.",
        "Only after those three are running does a bond, a SIF, a PMS or an AIF make sense. Skipping ahead is the most expensive mistake we see."
      ],
      opts: [
        ["Tell me about the six products", "products"],
        ["What is a SIF?", "sif"],
        ["Book a review", "book", true],
        ["Back to the start", "start"]
      ]
    },

    products: {
      say: [
        "Each of these has exactly one job:",
        "<strong>Mutual Funds</strong> — every goal, from about ₹500 a month.<br><strong>PMS</strong> — your own portfolio, ₹50 lakh minimum.<br><strong>Bonds</strong> — money with a date on it.<br><strong>AIF</strong> — specialised strategies, ₹1 crore minimum.<br><strong>SIF</strong> — between funds and PMS, ₹10 lakh.<br><strong>Insurance</strong> — protection only, never an investment.",
        'The full breakdown is on the <a href="solutions.html">solutions page</a>.'
      ],
      opts: [
        ["Do I need ₹50 lakh?", "minimums"],
        ["Book a review", "book", true],
        ["Back to the start", "start"]
      ]
    },

    sif: {
      say: [
        "A <strong>Specialised Investment Fund</strong> — a category SEBI opened up in 2025, sitting deliberately between a mutual fund and a PMS.",
        "It gives the manager more freedom than a mutual fund mandate allows — long-short, sector-rotation, hybrid strategies — while staying inside the mutual fund operating framework.",
        "Minimum is <strong>₹10 lakh per investor</strong> at PAN level across all SIF strategies of one fund house. Accredited investors are exempt from that floor.",
        "It's a young category, so we look hard at the manager rather than the marketing."
      ],
      opts: [
        ["What are the other minimums?", "minimums"],
        ["Book a review", "book", true],
        ["Back to the start", "start"]
      ]
    },

    minimums: {
      say: [
        "No — you don't need ₹50 lakh to work with us. Planning starts wherever you are.",
        "Some products do carry SEBI-prescribed floors: <strong>PMS ₹50 lakh</strong>, <strong>AIF ₹1 crore</strong>, <strong>SIF ₹10 lakh</strong>.",
        "But a mutual fund SIP can start at a few hundred rupees a month — and insurance and the emergency fund come before any of it."
      ],
      opts: [
        ["Which product do I need?", "which"],
        ["Book a review", "book", true],
        ["Back to the start", "start"]
      ]
    },

    fees: {
      say: [
        "You'll be told before you commit to anything — in rupees per year, not percentages, for every product discussed.",
        "<em>[Site owner: replace this with your actual fee model — advisory fee, distribution commission, or a combination — along with your registration details.]</em>"
      ],
      opts: [
        ["Book a review", "book", true],
        ["Back to the start", "start"]
      ]
    },

    book: {
      say: [
        "Good. The review is <strong>30 minutes, held over video</strong> — no cost and no pitch.",
        "Take you to the booking form?"
      ],
      opts: [
        ["Yes, open the form", "GO_BOOK", true],
        ["Not yet", "start"]
      ]
    }
  };

  /* -------------------------------------------------------------- build -- */
  var LOGO =
    '<svg class="chat-head__mark" viewBox="58 68 187 187" aria-hidden="true" fill="none" stroke="#E0402B" stroke-width="11" stroke-linecap="butt" stroke-linejoin="miter">' +
    '<path d="M111 116V187A20 20 0 0 1 91 207H67V77h38A32.5 32.5 0 0 1 137.5 109.5V246"/>' +
    '<path d="M192 116V187A20 20 0 0 0 212 207h24V77h-38A32.5 32.5 0 0 0 165.5 109.5V246"/></svg>';

  var launch = document.createElement("button");
  launch.className = "chat-launch";
  launch.type = "button";
  launch.setAttribute("aria-label", "Open the assistant");
  launch.innerHTML =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
    '<path d="M21 11.5a8.5 8.5 0 0 1-12.2 7.6L3 21l1.9-5.7A8.5 8.5 0 1 1 21 11.5z"/></svg><span>Ask a question</span>';

  var panel = document.createElement("div");
  panel.className = "chat-panel";
  panel.setAttribute("role", "dialog");
  panel.setAttribute("aria-label", "Minimal Wealth assistant");
  panel.innerHTML =
    '<div class="chat-head">' + LOGO +
      '<span class="chat-head__txt">' +
        '<span class="chat-head__name">Minimal Wealth assistant</span>' +
        '<span class="chat-head__sub">Answers in seconds &middot; not a person</span>' +
      '</span>' +
      '<button class="chat-close" type="button" aria-label="Close">' +
        '<svg width="15" height="15" viewBox="0 0 15 15" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M1 1l13 13M14 1L1 14"/></svg>' +
      '</button>' +
    '</div>' +
    '<div class="chat-log" id="chat-log" role="log" aria-live="polite"></div>' +
    '<div class="chat-opts" id="chat-opts"></div>' +
    '<p class="chat-foot">General information only, not personalised investment advice. ' +
      'Nothing typed here is stored or sent anywhere.</p>';

  document.body.appendChild(launch);
  document.body.appendChild(panel);

  var log     = panel.querySelector("#chat-log");
  var optWrap = panel.querySelector("#chat-opts");
  var started = false;
  var busy    = false;

  /* ------------------------------------------------------------ helpers -- */
  function bubble(html, who) {
    var el = document.createElement("div");
    el.className = "chat-msg chat-msg--" + who;
    el.innerHTML = html;
    log.appendChild(el);
    log.scrollTop = log.scrollHeight;
    return el;
  }

  function typing() {
    var el = document.createElement("div");
    el.className = "chat-typing";
    el.innerHTML = "<span></span><span></span><span></span>";
    log.appendChild(el);
    log.scrollTop = log.scrollHeight;
    return el;
  }

  function renderOpts(opts) {
    optWrap.innerHTML = "";
    opts.forEach(function (o) {
      var b = document.createElement("button");
      b.type = "button";
      b.className = "chat-opt" + (o[2] ? " chat-opt--cta" : "");
      b.textContent = o[0];
      b.addEventListener("click", function () {
        if (busy) return;
        bubble(o[0], "user");
        optWrap.innerHTML = "";
        if (o[1] === "GO_BOOK") {
          setTimeout(function () { window.location.href = BOOK_URL + "#enquiry-form"; }, 320);
          return;
        }
        go(o[1]);
      });
      optWrap.appendChild(b);
    });
  }

  function go(key) {
    var node = NODES[key];
    if (!node) return;
    busy = true;
    optWrap.innerHTML = "";

    var i = 0;
    (function next() {
      if (i >= node.say.length) {
        busy = false;
        renderOpts(node.opts);
        return;
      }
      var dots = typing();
      setTimeout(function () {
        dots.remove();
        bubble(node.say[i], "bot");
        i++;
        next();
      }, i === 0 ? 420 : 620);
    })();
  }

  /* -------------------------------------------------------------- open --- */
  function open() {
    panel.classList.add("is-open");
    launch.classList.add("is-hidden");
    if (!started) { started = true; go("start"); }
  }
  function close() {
    panel.classList.remove("is-open");
    launch.classList.remove("is-hidden");
  }

  launch.addEventListener("click", open);
  panel.querySelector(".chat-close").addEventListener("click", close);
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && panel.classList.contains("is-open")) close();
  });
})();
